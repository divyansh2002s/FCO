const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const SAMSARA_BASE_URL = "https://api.samsara.com";
const ML_PER_GALLON = 3785.411784;
const METERS_PER_MILE = 1609.344;

const SAMSARA_TOKENS = (process.env.SAMSARA_TOKEN || "")
  .split(",")
  .map((t) => t.trim())
  .filter(Boolean);

function ensureTokens() {
  if (!SAMSARA_TOKENS.length) {
    throw new Error("Missing SAMSARA_TOKEN in .env / Vercel environment variables");
  }
}

async function fetchJsonWithToken(pathOrUrl, token) {
  const url = pathOrUrl.startsWith("http")
    ? pathOrUrl
    : `${SAMSARA_BASE_URL}${pathOrUrl}`;

  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/json",
    },
  });

  const text = await response.text();
  let data = {};

  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = {};
  }

  if (!response.ok) {
    throw new Error(`Samsara error ${response.status}: ${text}`);
  }

  return data;
}

async function callSamsara(path) {
  ensureTokens();

  const mergedData = [];
  const errors = [];
  let sampleMeta = null;

  for (const token of SAMSARA_TOKENS) {
    try {
      const data = await fetchJsonWithToken(path, token);
      if (!sampleMeta) sampleMeta = data;

      if (Array.isArray(data.data)) {
        mergedData.push(...data.data);
      } else if (data.data !== undefined && data.data !== null) {
        mergedData.push(data.data);
      }
    } catch (error) {
      errors.push(error.message);
    }
  }

  if (!mergedData.length && errors.length === SAMSARA_TOKENS.length) {
    throw new Error(errors.join(" | "));
  }

  return {
    ...(sampleMeta || {}),
    data: mergedData,
  };
}

async function callSamsaraPaginated(path) {
  ensureTokens();

  const allData = [];
  const errors = [];

  for (const token of SAMSARA_TOKENS) {
    let nextPath = path;

    while (nextPath) {
      try {
        const data = await fetchJsonWithToken(nextPath, token);
        allData.push(...(data.data || []));

        const hasNextPage = data.pagination?.hasNextPage;
        const endCursor = data.pagination?.endCursor;

        if (!hasNextPage || !endCursor) {
          nextPath = null;
        } else {
          const separator = path.includes("?") ? "&" : "?";
          nextPath = `${path}${separator}after=${encodeURIComponent(endCursor)}`;
        }
      } catch (error) {
        errors.push(error.message);
        nextPath = null;
      }
    }
  }

  if (!allData.length && errors.length) {
    throw new Error(errors.join(" | "));
  }

  return allData;
}

function numberOrNull(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function latestByTime(items) {
  if (!Array.isArray(items) || items.length === 0) return null;

  return (
    items
      .filter(Boolean)
      .sort((a, b) => {
        const at = new Date(a.time || a.updatedAt || 0).getTime();
        const bt = new Date(b.time || b.updatedAt || 0).getTime();
        return bt - at;
      })[0] || null
  );
}

function latestStat(vehicle, key) {
  const value = vehicle[key];
  if (Array.isArray(value)) return latestByTime(value);
  return value || null;
}

function extractFuelPercent(raw) {
  if (!raw) return null;

  if (Array.isArray(raw)) {
    const latest = latestByTime(raw);
    return extractFuelPercent(latest);
  }

  return (
    numberOrNull(raw.percent) ??
    numberOrNull(raw.value) ??
    numberOrNull(raw.fuelPercent) ??
    numberOrNull(raw.fuelPercentRemaining) ??
    numberOrNull(raw.engineFuelLevelPercent) ??
    null
  );
}

function extractFuelTime(raw) {
  if (!raw) return null;

  if (Array.isArray(raw)) {
    const latest = latestByTime(raw);
    return extractFuelTime(latest);
  }

  return raw.time || raw.updatedAt || null;
}

function isoHoursAgo(hours) {
  return new Date(Date.now() - hours * 60 * 60 * 1000).toISOString();
}

function isoNow() {
  return new Date().toISOString();
}

function isoDateDaysAgo(days = 30) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString();
}

function isoDateToday() {
  return new Date().toISOString();
}

function extractFuelEnergyReportArray(json) {
  if (!json) return [];

  if (Array.isArray(json.data)) return json.data;

  const data = json.data || json;

  const candidateArrays = [
    data.vehicleReports,
    data.reports,
    data.vehicles,
    data.items,
    data.results,
    json.vehicleReports,
    json.reports,
    json.vehicles,
    json.items,
    json.results,
  ];

  for (const arr of candidateArrays) {
    if (Array.isArray(arr)) return arr;
  }

  return [];
}

function findNumberByKeyDeep(value, predicate) {
  if (!value || typeof value !== "object") return "";

  const stack = [value];

  while (stack.length) {
    const current = stack.pop();

    if (!current || typeof current !== "object") continue;

    if (Array.isArray(current)) {
      current.forEach((item) => stack.push(item));
      continue;
    }

    for (const [key, raw] of Object.entries(current)) {
      if (predicate(key)) {
        const n = Number(raw);
        if (Number.isFinite(n)) return n;
      }

      if (raw && typeof raw === "object") {
        stack.push(raw);
      }
    }
  }

  return "";
}

function extractVehicleIdFromFuelEnergyReport(report) {
  return String(
    report?.vehicle?.id ??
    report?.vehicleId ??
    report?.vehicleID ??
    report?.vehicle?.vehicleId ??
    ""
  );
}

function extractMilesFromFuelEnergyReport(report) {
  const direct = findNumberByKeyDeep(report, (key) => {
    const k = key.toLowerCase();
    return (
      k === "miles" ||
      k.includes("distancemiles") ||
      k.includes("milesdriven") ||
      k.includes("totalmiles") ||
      k.includes("odometermiles")
    );
  });

  if (direct !== "") return Number(direct);

  const meters = findNumberByKeyDeep(report, (key) => {
    const k = key.toLowerCase();
    return (
      k === "meters" ||
      k.includes("distancemeters") ||
      k.includes("metersdriven") ||
      k.includes("totalmeters")
    );
  });

  if (meters !== "") return Number(meters) / METERS_PER_MILE;

  return "";
}

function extractGallonsFromFuelEnergyReport(report) {
  const direct = findNumberByKeyDeep(report, (key) => {
    const k = key.toLowerCase();
    return (
      k === "gallons" ||
      k.includes("fuelconsumedgallons") ||
      k.includes("totalgallons") ||
      k.includes("fuelgallons")
    );
  });

  if (direct !== "") return Number(direct);

  const milliliters = findNumberByKeyDeep(report, (key) => {
    const k = key.toLowerCase();
    return (
      k === "milliliters" ||
      k.includes("fuelconsumedmilliliters") ||
      k.includes("millilitres") ||
      k.includes("ml")
    );
  });

  if (milliliters !== "") return Number(milliliters) / ML_PER_GALLON;

  return "";
}

function extractMpgFromFuelEnergyReport(report) {
  const direct = findNumberByKeyDeep(report, (key) => {
    const k = key.toLowerCase().replace(/\s+/g, "");
    return (
      k === "mpg" ||
      k.includes("milespergallon") ||
      k.includes("fuelefficiencympg") ||
      k.includes("averagempg")
    );
  });

  if (direct !== "") return Number(direct);

  const miles = extractMilesFromFuelEnergyReport(report);
  const gallons = extractGallonsFromFuelEnergyReport(report);

  if (Number.isFinite(miles) && Number.isFinite(gallons) && gallons > 0) {
    return miles / gallons;
  }

  return "";
}

async function fetchFuelEnergyReportsForToken(token, params) {
  const results = [];
  let after = "";
  let hasNextPage = true;
  let pageCount = 0;

  while (hasNextPage) {
    const pageParams = { ...params };
    if (after) pageParams.after = after;

    const url =
      `${SAMSARA_BASE_URL}/fleet/reports/vehicles/fuel-energy?` +
      new URLSearchParams(pageParams).toString();

    const json = await fetchJsonWithToken(url, token);
    const pageReports = extractFuelEnergyReportArray(json);

    pageReports.forEach((item) => results.push(item));

    const pagination = json.pagination || json.data?.pagination || {};
    hasNextPage = pagination.hasNextPage === true;
    after = pagination.endCursor || "";

    if (hasNextPage && !after) {
      throw new Error("Fuel & Energy pagination hasNextPage=true but no endCursor returned.");
    }

    pageCount += 1;
    if (pageCount > 10000) {
      throw new Error("Stopped after 10,000 Fuel & Energy pages to prevent infinite loop.");
    }
  }

  return results;
}

async function getFuelHistoryMap(hoursBack = 168) {
  const startTime = isoHoursAgo(hoursBack);
  const endTime = isoNow();

  const params = new URLSearchParams({
    types: "fuelPercents",
    startTime,
    endTime,
  });

  const rows = await callSamsaraPaginated(
    `/fleet/vehicles/stats/history?${params.toString()}`
  );

  const fuelMap = new Map();

  for (const vehicle of rows) {
    const rawFuel = vehicle.fuelPercents ?? null;
    const fuelPercent = extractFuelPercent(rawFuel);
    const fuelTime = extractFuelTime(rawFuel);

    if (fuelPercent !== null) {
      fuelMap.set(String(vehicle.id), {
        fuelPercent,
        fuelTime,
        fuelRaw: rawFuel,
      });
    }
  }

  return fuelMap;
}

async function getVehicleMilesFromOdometerHistory(vehicleId, startTime, endTime) {
  const params = new URLSearchParams({
    types: "obdOdometerMeters",
    startTime,
    endTime,
    vehicleIds: vehicleId,
  });

  const rows = await callSamsaraPaginated(
    `/fleet/vehicles/stats/history?${params.toString()}`
  );

  const readings = [];

  for (const vehicle of rows) {
    if (String(vehicle.id) !== String(vehicleId)) continue;

    const raw = vehicle.obdOdometerMeters ?? null;
    const items = Array.isArray(raw) ? raw : raw ? [raw] : [];

    for (const item of items) {
      const meters =
        numberOrNull(item?.meters) ??
        numberOrNull(item?.value) ??
        null;

      const time = item?.time || item?.updatedAt || null;

      if (meters !== null && time) {
        readings.push({
          meters,
          time: new Date(time).getTime(),
        });
      }
    }
  }

  if (readings.length < 2) return null;

  readings.sort((a, b) => a.time - b.time);

  const first = readings[0];
  const last = readings[readings.length - 1];

  if (!first || !last || last.meters <= first.meters) return null;

  return (last.meters - first.meters) / METERS_PER_MILE;
}

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    message: "Local Samsara backend is running",
    tokensLoaded: SAMSARA_TOKENS.length,
  });
});

app.get("/api/samsara/vehicle-fuel-efficiency", async (req, res) => {
  try {
    ensureTokens();

    const vehicleId = String(req.query.vehicleId || "").trim();
    if (!vehicleId) {
      return res.status(400).json({
        success: false,
        error: "vehicleId is required",
      });
    }

    const days = Number(req.query.days || 30);
    const safeDays = Number.isFinite(days) && days > 0 ? Math.min(days, 90) : 30;

    const startTime = isoDateDaysAgo(safeDays);
    const endTime = isoDateToday();

    const params = {
      startDate: startTime,
      endDate: endTime,
      vehicleIds: vehicleId,
      energyType: "fuel",
    };

    const tokenErrors = [];

    for (let i = 0; i < SAMSARA_TOKENS.length; i++) {
      const token = SAMSARA_TOKENS[i];

      try {
        const reports = await fetchFuelEnergyReportsForToken(token, params);
        const report =
          reports.find((r) => extractVehicleIdFromFuelEnergyReport(r) === vehicleId) ||
          reports[0];

        if (!report) continue;

        const rawMpg = extractMpgFromFuelEnergyReport(report);
        let miles = extractMilesFromFuelEnergyReport(report);
        const gallons = extractGallonsFromFuelEnergyReport(report);

        if (!Number.isFinite(miles)) {
          try {
            miles = await getVehicleMilesFromOdometerHistory(vehicleId, startTime, endTime);
          } catch (odomErr) {
            tokenErrors.push(`odometer fallback failed: ${odomErr.message}`);
          }
        }

        let mpg = rawMpg;
        if (!Number.isFinite(mpg) && Number.isFinite(miles) && Number.isFinite(gallons) && gallons > 0) {
          mpg = miles / gallons;
        }

        return res.json({
          success: true,
          vehicleId,
          mpg: Number.isFinite(mpg) ? Number(mpg.toFixed(2)) : null,
          miles: Number.isFinite(miles) ? Number(miles.toFixed(2)) : null,
          gallons: Number.isFinite(gallons) ? Number(gallons.toFixed(2)) : null,
          source: Number.isFinite(rawMpg) ? "fuel-energy" : "fuel-energy + odometer-history",
          tokenIndex: i + 1,
          period: {
            startDate: startTime,
            endDate: endTime,
            days: safeDays,
          },
          error: tokenErrors.length ? tokenErrors.join(" | ") : null,
        });
      } catch (error) {
        tokenErrors.push(error.message);
      }
    }

    return res.json({
      success: true,
      vehicleId,
      mpg: null,
      miles: null,
      gallons: null,
      source: "fuel-energy",
      period: {
        startDate: startTime,
        endDate: endTime,
        days: safeDays,
      },
      error: tokenErrors.join(" | ") || "No fuel efficiency found for this vehicle",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

app.get("/api/samsara/vehicles", async (req, res) => {
  try {
    const snapshotData = await callSamsara(
      "/fleet/vehicles/stats?types=gps,fuelPercents,obdOdometerMeters"
    );

    let fuelHistoryMap = new Map();
    let fuelHistoryError = null;

    try {
      fuelHistoryMap = await getFuelHistoryMap(168);
    } catch (historyError) {
      fuelHistoryError = historyError.message;
    }

    const vehicles = (snapshotData.data || []).map((vehicle) => {
      const gps = latestStat(vehicle, "gps");
      const snapshotFuel = latestStat(vehicle, "fuelPercents");
      const odometer = latestStat(vehicle, "obdOdometerMeters");

      const snapshotFuelPercent = extractFuelPercent(snapshotFuel);
      const snapshotFuelTime = extractFuelTime(snapshotFuel);

      const historyFuel = fuelHistoryMap.get(String(vehicle.id)) || null;

      const finalFuelPercent =
        snapshotFuelPercent !== null
          ? snapshotFuelPercent
          : historyFuel?.fuelPercent ?? null;

      const finalFuelTime = snapshotFuelTime || historyFuel?.fuelTime || null;

      const fuelSource =
        snapshotFuelPercent !== null
          ? "snapshot"
          : historyFuel?.fuelPercent !== undefined
          ? "history"
          : null;

      const odometerMeters =
        numberOrNull(odometer?.meters) ??
        numberOrNull(odometer?.value) ??
        null;

      return {
        id: vehicle.id,
        name: vehicle.name,
        latitude:
          numberOrNull(gps?.latitude) ??
          numberOrNull(gps?.value?.latitude) ??
          null,
        longitude:
          numberOrNull(gps?.longitude) ??
          numberOrNull(gps?.value?.longitude) ??
          null,
        speedMph:
          numberOrNull(gps?.speedMilesPerHour) ??
          numberOrNull(gps?.value?.speedMilesPerHour) ??
          null,
        address:
          gps?.reverseGeo?.formattedLocation ??
          gps?.value?.reverseGeo?.formattedLocation ??
          null,
        fuelPercent: finalFuelPercent,
        fuelTime: finalFuelTime,
        fuelSource,
        odometerMeters,
        odometerMiles:
          odometerMeters !== null ? odometerMeters / 1609.344 : null,
        gpsTime: gps?.time ?? null,
        odometerTime: odometer?.time ?? null,
      };
    });

    res.json({
      success: true,
      count: vehicles.length,
      fuelHistoryFallbackUsed: true,
      fuelHistoryError,
      vehicles,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

app.get("/api/samsara/fuel-diagnostics", async (req, res) => {
  try {
    const snapshotData = await callSamsara(
      "/fleet/vehicles/stats?types=fuelPercents,fuelConsumedMilliliters,obdOdometerMeters"
    );

    let historyRows = [];
    let historyError = null;

    try {
      const params = new URLSearchParams({
        types: "fuelPercents",
        startTime: isoHoursAgo(168),
        endTime: isoNow(),
      });

      historyRows = await callSamsaraPaginated(
        `/fleet/vehicles/stats/history?${params.toString()}`
      );
    } catch (err) {
      historyError = err.message;
    }

    const historyMap = new Map();

    for (const vehicle of historyRows) {
      const fuelPercent = extractFuelPercent(vehicle.fuelPercents);
      const fuelTime = extractFuelTime(vehicle.fuelPercents);

      if (fuelPercent !== null) {
        historyMap.set(String(vehicle.id), {
          fuelPercent,
          fuelTime,
          raw: vehicle.fuelPercents,
        });
      }
    }

    const vehicles = (snapshotData.data || []).map((vehicle) => {
      const snapshotFuel = vehicle.fuelPercents ?? null;
      const historyFuel = historyMap.get(String(vehicle.id)) || null;

      return {
        id: vehicle.id,
        name: vehicle.name,
        snapshotFuelRaw: snapshotFuel,
        snapshotFuelPercent: extractFuelPercent(snapshotFuel),
        snapshotFuelTime: extractFuelTime(snapshotFuel),
        historyFuelPercent: historyFuel?.fuelPercent ?? null,
        historyFuelTime: historyFuel?.fuelTime ?? null,
        historyFuelRaw: historyFuel?.raw ?? null,
        fuelConsumedMillilitersRaw:
          vehicle.fuelConsumedMilliliters ?? null,
        odometerRaw: vehicle.obdOdometerMeters ?? null,
      };
    });

    res.json({
      success: true,
      count: vehicles.length,
      note: "Checks snapshot fuel first, then fuelPercents from Vehicle Stats History for last 7 days.",
      historyRowsFound: historyRows.length,
      historyError,
      vehicles,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

app.get("/api/samsara/fuel-history", async (req, res) => {
  try {
    const hours = Number(req.query.hours || 168);
    const safeHours = Number.isFinite(hours) && hours > 0 ? hours : 168;

    const params = new URLSearchParams({
      types: "fuelPercents",
      startTime: isoHoursAgo(safeHours),
      endTime: isoNow(),
    });

    const rows = await callSamsaraPaginated(
      `/fleet/vehicles/stats/history?${params.toString()}`
    );

    const vehicles = rows.map((vehicle) => ({
      id: vehicle.id,
      name: vehicle.name,
      fuelPercent: extractFuelPercent(vehicle.fuelPercents),
      fuelTime: extractFuelTime(vehicle.fuelPercents),
      fuelPercentsRaw: vehicle.fuelPercents ?? null,
    }));

    res.json({
      success: true,
      count: vehicles.length,
      hoursBack: safeHours,
      vehicles,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

app.listen(PORT, () => {
  console.log(`Backend running at http://127.0.0.1:${PORT}`);
});
